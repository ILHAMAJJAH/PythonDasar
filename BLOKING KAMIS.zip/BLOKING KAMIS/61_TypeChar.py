import PySimpleGUI as sg 

sg.theme('BluePurple')

layout = [[sg.Text('Your type chars appear here:'), sg.Text(size=(15,1), key='-OUTPUT-')],
          [sg.Input(key='-IN-')],
          [sg.Button('show'), sg.Button('Exit')]]

window = sg.Window('Pattern 2B', layout)

while True: 
    event, values = window.read()
    print(event, values)
    if event == sg.WIN_CLOSED or event == 'Exit':
        break 
    if event == 'show':
        
        window['_OUTPUT_'].update(values['_IN_'])
        
window.close()