import tkinter as tk

# Fungsi untuk menghitung total harga
def hitung_total():
    harga_barang = float(entry_harga.get())
    kuantitas = int(entry_kuantitas.get())
    total = harga_barang * kuantitas
    label_total.config(text=f"Total: Rp {total:.2f}")

# Membuat jendela aplikasi
app = tk.Tk()
app.title("Program Kasir")

# Label dan input harga barang
label_harga = tk.Label(app, text="Harga :")
label_harga.pack()
entry_harga = tk.Entry(app)
entry_harga.pack()

# Label dan input kuantitas barang
label_kuantitas = tk.Label(app, text="Kuantitas:")
label_kuantitas.pack()
entry_kuantitas = tk.Entry(app)
entry_kuantitas.pack()

# Tombol untuk menghitung total harga
tombol_hitung = tk.Button(app, text="Hitung Total", command=hitung_total)
tombol_hitung.pack()

# Label untuk menampilkan total harga
label_total = tk.Label(app, text="")
label_total.pack()

# Menjalankan aplikasi
app.mainloop()
